<?php
session_start();
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome_usuario'];
    $CPF = $_POST['CPF_usuario'];
    $CNPJ = $_POST['CNPJ_usuario'];
    $dta = $_POST['dta_nascimento'];
    $email = $_POST['email_usuario'];
    $email_conf = $_POST['conf_email'];
    $senha = $_POST['senha_cad'];
    $senha_conf = $_POST['conf_senha'];

    $erro = "";

    if ($senha != $senha_conf) {
        $erro = "Erro. As senhas estão diferentes.";
    } elseif ($email != $email_conf) {
        $erro = "Erro. Os emails não coincidem.";
    } else {
        $comando = $conn->prepare("INSERT INTO tb_cadastro (nome_cadastro, CPF_cadastro, CNPJ_cadastro, dta_nasc_cadastro, email_cadastro, senha_cadastro) 
                                   VALUES (?, ?, ?, ?, ?, ?)");

        if ($comando === false) {
            $erro = "Erro ao preparar a query: " . $conn->error;
        } else {
            $comando->bind_param("ssssss", $nome, $CPF, $CNPJ, $dta, $email, $senha);

            if ($comando->execute()) {
                echo "<!DOCTYPE html>
                      <html lang='pt-BR'>
                      <head>
                          <meta charset='UTF-8'>
                          <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                          <link rel='stylesheet' type='text/css' href='../CSS/css_cadastro_login.css'>
                          <title>Cadastro realizado</title>
                      </head>
                      <body>

                      <div class='main'>
                          <div class='caixa_texto'>
                              <h1>Cadastro realizado com sucesso</h1><br>
                              <a href='../login.php'>Fazer login</a>
                          </div>
                       </div>
                      </body>
                      </html>";
                exit();
            } else {
                $erro = "Erro ao cadastrar: " . $comando->error;
            }

            $comando->close();
        }
    }

    if (!empty($erro)) {
        echo "<script>alert('$erro');</script>";
    }
}

$conn->close();
?>