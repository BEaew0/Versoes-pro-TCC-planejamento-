<?php
session_start();
header('Content-Type: text/html; charset=utf-8');

include 'PHP/conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['botao']) && $_POST['botao'] == 'logar') {
        if (isset($_POST['nome_login']) && isset($_POST['log_pessoa']) && isset($_POST['senha_log'])) {
            $nome = $_POST['nome_login'];
            $tipo = $_POST['log_pessoa'];
            $senha = $_POST['senha_log'];

            if (strlen($tipo) == 0) {
                echo "Preencha seu CPF ou CNPJ!";
            } else if (strlen($nome) == 0) {
                echo "Preencha seu nome!";
            } else if (strlen($senha) == 0) {
                echo "Preencha sua senha!";
            } else {
                $sql = "SELECT id_cadastro, nome_cadastro, CPF_cadastro, senha_cadastro FROM tb_cadastro ";

                if (strlen($tipo) == 11) {
                    // Se for CPF (11 caracteres)
                    $sql .= " WHERE CPF_cadastro = ?";
                } else if (strlen($tipo) == 14) {
                    // Se for CNPJ (14 caracteres)
                    $sql .= " WHERE CNPJ_cadastro = ?";
                } else {
                    echo "CPF ou CNPJ inválido!";
                    exit;
                }

                $comando = $conn->prepare($sql);
                $comando->bind_param("s", $tipo);
                $comando->execute();
                $result = $comando->get_result();

                if ($result->num_rows > 0) {
                    // Usuário encontrado, verifica a senha
                    $usuario = $result->fetch_assoc();

                    if ($senha == $usuario['senha_cadastro']) {
                        // Senha correta, salva os dados na sessão

                      
                        $_SESSION['id_usuario'] = $usuario['id_cadastro'];
                        $_SESSION['nome_usuario'] = $usuario['nome_cadastro'];
                        $_SESSION['tipo_usuario'] = (strlen($tipo) == 11) ? 'CPF' : 'CNPJ';

                     echo"<script>
                    
                     window.location.href='pag_principal.html';

                         alert('Cadastro realizado com sucesso');
                         
                     </script>";
                        exit(); 
                    } else {
                        echo "Senha incorreta!";
                        exit;
                    }
                } else {
                    echo "Usuário não encontrado!";
                    exit;
                }
            }
        }
    }
} else {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="../CSS-TCC_WEB-versão-14-2/CSS/css_cadastro_login.css">
</head>
<body>
    <div class="main-login">
        <form action="login.php" method="post"> <!-- Caminho corrigido -->
            <div id="titulo"><label>Login</label></div><br>
            <label for="nome_login">Nome:</label><br>
            <input type="text" name="nome_login" id="nome" required><br>
            <label for="log_pessoa">CPF/CNPJ:</label><br>
            <input type="text" name="log_pessoa" id="pessoafj" required><br>
            <label for="senha_log">Senha:</label><br>
            <input type="password" name="senha_log" id="senha" required><br>
            <button type="submit" name="botao" value="logar">Logar</button><br>
            <div id="linha-divisoria"></div>
            <a href="cadastro.html">Cadastrar</a> | 
            <a href="recuperar_senha.php">Esqueceu a senha?</a>
        </form>
    </div>
</body>
</html>
<?php
}
?>