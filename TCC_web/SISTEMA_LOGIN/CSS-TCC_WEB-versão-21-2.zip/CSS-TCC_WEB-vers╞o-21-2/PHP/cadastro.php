<?php
session_start();
include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST')
 {
    $nome = $_POST['nome_usuario'];
    $CPF = $_POST['CPF_usuario'];
    $CNPJ = $_POST['CNPJ_usuario'];
    $dta = $_POST['dta_nascimento'];
    $email = $_POST['email_usuario'];
    $email_conf = $_POST['conf_email'];
    $senha = $_POST['senha_cad'];
    $senha_conf = $_POST['conf_senha'];

    $erro = "";

    $senha_hash  = password_hash($senha, PASSWORD_DEFAULT);

    if ($senha != $senha_conf) 
    {
        $erro = "Erro. As senhas estão diferentes.";
        echo"<script>alert('$erro')</script>";
        //header("location:../cadastro.html");
    }
    elseif(strlen($CPF) == 0  && strlen($CPF) < 11)
    {
        
    }
    elseif ($email != $email_conf) 
    {
        $erro = "Erro. Os emails não coincidem.";
    } 
    else 
    {
        $comando = $conn->prepare("INSERT INTO tb_cadastro (nome_cadastro, CPF_cadastro, CNPJ_cadastro, dta_nasc_cadastro, email_cadastro, senha_cadastro) 
                                   VALUES (?, ?, ?, ?, ?, ?)");

        if ($comando === false) 
        {
            $erro = "Erro ao preparar a query: " . $conn->error;
        } 
        
        else 
        {
            $comando->bind_param("ssssss", $nome, $CPF, $CNPJ, $dta, $email, $senha_hash);

            if ($comando->execute()) 
            {
                echo "<!DOCTYPE html>
                      <html lang='pt-BR'>
                      <head>
                          <meta charset='UTF-8'>
                          <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                          <link rel='stylesheet' type='text/css' href='../CSS/css_cadastro_login.css'>
                          <title>Cadastro realizado com sucesso!</title>
                      </head>
                      <body>

                      <div class='main'>
                          <div class='caixa_texto'>
                              <h1>Cadastro realizado com sucesso</h1><br>
                              <a href='../login.html'>Fazer login</a>
                          </div>
                       </div>
                      </body>
                      </html>";
                exit();
            } 
            else 
            {
                $erro = "Erro ao cadastrar: " . $comando->error;
            }

            $comando->close();
        }
    }

    if (!empty($erro)) 
    {
        echo "<script>alert('$erro');</script>";
    }
}

$conn->close();
?>