console.log('Node ta isntalado');

let conta = 1+1;

console.log(conta);