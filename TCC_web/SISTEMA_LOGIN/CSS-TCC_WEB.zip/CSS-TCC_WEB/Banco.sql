Create database sistema_tesouro_azul;

use sistema_tesouro_azul;


create table tb_cadastro
(id_cadastro int auto_increment,
nome_cadastro varchar (35) not null,
cpf_cadastro
);


create table tb_fisica_juridica(
id_pes_fisica int auto_increment

);