<?php
session_start();

include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome_usuario'];
    $CPF= $_POST['CPF_usuario"'];
    $CNPJ = $_POST['CNPJ_usuario'];
    $email = $_POST['email_usuario'];
    $email_conf= $_POST['conf_email'];
    $senha = $_POST['senha_cad'];
    $senha_conf=$_POST['conf_senha'];
    $dta = $_POST['dta_nascimento'];
}

if ($senha == $conf_senha && $email == $email_conf) {
 
    $sql = "INSERT INTO tb_cadastro (nome_cadastro, CPF_cadastro, CNPJ_cadastro, dta_nasc_cadastro,email_cadastro  senha_cadastro) 
            VALUES ('$nome','$$CPF', '$CNPJ', '$email', '$senha','$dta' )";
    
    if ($conn->query($sql) === TRUE) {
        
        header("Location: login.html");
        exit();
    } else {
        $erro = "Erro ao cadastrar: " . $conn->error;
    }
} 
 if() 
{
    $erro = "As senhas não coincidem.";
}



?>