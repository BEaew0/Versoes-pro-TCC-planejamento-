document.addEventListener('DOMContentLoaded', function() {
    const temaBotao = document.getElementById('btn_tema');
    const root = document.documentElement;
  

    const temaSalvo = localStorage.getItem('data-tema');

    if (temaSalvo) {
      root.setAttribute('data-tema', temaSalvo);
      
    } else {
      // Se não houver tema salvo, define o tema padrão como 'dark'
      root.setAttribute('data-tema', 'light');
    
    }
  
    // Adiciona um evento de clique ao botão de tema


    temaBotao.addEventListener('click', function() 
    {
      const icon_claro="<i class='fa-solid fa-sun'id='icon_tema'>";
      const icon_dark="<i class='fa-solid fa-moon' id='icon_tema'></i>"

      const temaAtual = root.getAttribute('data-tema');
      if (temaAtual === 'dark') {
        root.setAttribute('data-tema', 'light');
        temaBotao.classList.add('ativo');
        temaBotao.innerHTML=icon_claro;
    

        localStorage.setItem('tema', 'light');

  
      }
       else 
      {
        root.setAttribute('data-tema', 'dark');
  
        localStorage.setItem('tema', 'dark');
        temaBotao.classList.remove('ativo');
        temaBotao.innerHTML=icon_dark;
    

       
      }
    });

  });