const string='nome=dora&idade=10';

const url=  new URLSearchParams(string);

console.log(url);