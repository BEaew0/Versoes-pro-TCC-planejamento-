<?php

declare(strict_types=1);


class ValidarCadastro {

    private $nome;
    private $CPF;
    private $CNPJ;
    private $dta_nasc;
    private $email;
    private $conf_email;
    private $senha;
    private $conf_senha;
    private $conn;

    function __construct(
        string $nome, 
        string $CPF, 
        string $CNPJ,
        string $dta_nasc, 
        string $email, 
        string $conf_email, 
        string $senha, 
        string $conf_senha, 
        object $conn) 
        {
        // Atribuindo valores aos atributos da classe
        $this->nome = $nome;
        $this->CPF = $CPF;
        $this->CNPJ = $CNPJ;
        $this->dta_nasc = $dta_nasc;
        $this->email = $email;
        $this->conf_email = $conf_email;
        $this->senha = $senha;
        $this->conf_senha = $conf_senha;
        $this->conn = $conn;
    }

    function validacao() {
        $errors = []; // Corrigido o nome da variável para "errors"

        // Criando um array com os dados a serem validados
        $data = [
            'nome' => $this->nome,
            'CPF' => $this->CPF,
            'CNPJ' => $this->CNPJ,
            'dta_nascimento' => $this->dta_nasc,
            'email' => $this->email,
            'conf_email' => $this->conf_email,
            'senha' => $this->senha,
            'conf_senha' => $this->conf_senha
        ];

        // Validação dos campos
        foreach ($data as $campo => $valor) {
            switch ($campo) {
                case 'nome':
                    if (empty($valor)) {
                        $errors['nome'] = 'Nome é obrigatório';
                    } elseif (strlen($valor) < 3) {
                        $errors['nome'] = 'Nome deve ter pelo menos 3 caracteres';
                    }
                    break;
                    
                case 'CPF':
                    if (!empty($valor) && !$this->validarCPF($valor)) {
                        $errors['CPF'] = 'CPF inválido';
                    } elseif (empty($valor)) {
                        $errors['CPF'] = 'Preencha seu CPF';
                    }
                    break;
                    
                case 'CNPJ':
                    if (!empty($valor) && !$this->validarCNPJ($valor)) {
                        $errors['CNPJ'] = 'CNPJ inválido';
                    }
                    break;
                    
                case 'dta_nascimento':
                    if (empty($valor)) {
                        $errors['dta_nascimento'] = 'Insira sua data de nascimento';
                    }
                    break;
                    
                case 'email':
                    if (empty($valor)) {
                        $errors['email'] = 'Email é obrigatório';
                    } 
                    elseif (!filter_var($valor, FILTER_VALIDATE_EMAIL)) {
                        $errors['email'] = 'Email inválido';
                    }
                    break;
                    
                case 'conf_email':

                    if ($valor !== $this->email) {
                        $errors['conf_email'] = 'Emails não coincidem';
                    }
                    else{
                        $errors['conf_email'] = 'Insira o mesmo email';

                    }
                    break;
                    
                case 'senha':
                    if (empty($valor)) {
                        $errors['senha'] = 'Senha é obrigatória';
                    } elseif (strlen($valor) < 8) {
                        $errors['senha'] = 'Senha deve ter pelo menos 8 caracteres';
                    }
                    break;
                    
                case 'conf_senha':
                    if ($valor !== $this->senha) {
                        $errors['conf_senha'] = 'Senhas não coincidem';
                    }
                    break;
            }
        }

        return $errors; // Corrigido o nome da variável para "errors"
    }

    function validarCPF($CPF) {

        $CPF = preg_replace( '/[^0-9]/is', '', $CPF );
     
        // Verifica se foi informado todos os digitos corretamente
        if (strlen($CPF) != 11) {
            return false;
        }
    
        // Verifica se foi informada uma sequência de digitos repetidos. Ex: 111.111.111-11
        if (preg_match('/(\d)\1{10}/', $CPF)) {
            return false;
        }

        $D1=0;
        $D2=0;
    
        // Faz o calculo para validar o CPF
        for ($i = 0;$x=10, $i < 8; $i++,$x--) {
            $D1+= $CPF[$i]*$x;
    
        }
        for ($i = 0;$x=11, $i < 9; $i++,$x--) {
            $D2+= $CPF[$i]*$x;

            if(preg_match('/(\d)\1{10}/', $CPF))
            {
                die('Não, repita');
            } 
        }

        //verificação do digito1 e digito2

        $V1 = $D1%11;
        $V2= $D2%11;

        $resultado1=(($V1<2)?0:11-($V1));
        $resultado2=(($V2<2)?0:11-($V2));

      if($resultado1 != $CPF[9]|| $resultado2!= $CPF[10]){
        return false;
      }
      else{
        return true;
      }






        return true;
    }

    function validarCNPJ($CNPJ) {
        $CNPJ = preg_replace('/[^0-9]/', '', $CNPJ);
	
        // Valida tamanho
        if (strlen($CNPJ) != 14)
            return false;
    
        // Verifica se todos os digitos são iguais
        if (preg_match('/(\d)\1{13}/', $CNPJ))
            return false;	
    
        // Valida primeiro dígito verificador
        for ($i = 0, $j = 5, $soma = 0; $i < 12; $i++)
        {
            $soma += $CNPJ[$i] * $j;
            $j = ($j == 2) ? 9 : $j - 1;
        }
    
        $resto = $soma % 11;
    
        if ($CNPJ[12] != ($resto < 2 ? 0 : 11 - $resto))
            return false;
    
        // Valida segundo dígito verificador
        for ($i = 0, $j = 6, $soma = 0; $i < 13; $i++)
        {
            $soma += $CNPJ[$i] * $j;
            $j = ($j == 2) ? 9 : $j - 1;
        }
    
        $resto = $soma % 11;
    
        return $CNPJ[13] == ($resto < 2 ? 0 : 11 - $resto);
    }
}
    // Lógica para validar a data de nascimento
    


?>
