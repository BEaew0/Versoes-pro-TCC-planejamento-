
// Option 2: Using querySelector
document.querySelector('.form-cadastro').addEventListener('submit', function(e) 
    // rest of the code remains the same
 {
    e.preventDefault();
    
    const formData = new FormData(this);
    const xhr = new XMLHttpRequest();
    
    xhr.open('POST', '../PHP/cadastro.php', true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    
    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            
            if (response.success) {
                // Cadastro bem-sucedido
                document.getElementById('mostrar_erro').innerHTML = `
                    <div class="success">${response.message}</div>
                    <a href="../login.html">Fazer login</a>
                `;
            } else {
                // Exibir erro
                document.getElementById('mostrar_erro').innerHTML = `
                    <div class="error">${response.message}</div>
                `;
            }
        } else {
            document.getElementById('mostrar_erro').innerHTML = `
                <div class="error">Erro na conexão com o servidor</div>
            `;
        }
    };
    
    xhr.send(formData);
});