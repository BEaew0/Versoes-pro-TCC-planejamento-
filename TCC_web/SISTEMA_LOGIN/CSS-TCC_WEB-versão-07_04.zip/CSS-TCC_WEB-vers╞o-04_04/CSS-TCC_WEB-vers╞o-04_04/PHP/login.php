<?php
session_start();
header('Content-Type: text/html; charset=utf-8');

include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['botao']) && $_POST['botao'] == 'logar')
     {
        if (isset($_POST['nome_login']) && isset($_POST['log_pessoa']) && isset($_POST['senha_log'])) {
            $nome = $_POST['nome_login'];
            $tipo = $_POST['log_pessoa'];
            $senha = $_POST['senha_log'];

           


            else 
            {
                

           
            }
        }
    }
}
?>