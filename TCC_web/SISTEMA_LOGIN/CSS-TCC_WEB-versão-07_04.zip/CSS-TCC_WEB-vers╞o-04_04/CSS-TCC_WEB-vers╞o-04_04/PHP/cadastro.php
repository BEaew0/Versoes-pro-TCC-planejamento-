<?php
session_start();
include 'conexao.php';
require 'selects.php';

include 'validarCadastro.php';



if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome_usuario'];
    $CPF = $_POST['CPF_usuario'];
    $CNPJ = $_POST['CNPJ_usuario'];
    $dta_nasc = $_POST['dta_nascimento'];
    $email = $_POST['email_usuario'];
    $email_conf = $_POST['conf_email'];
    $senha = $_POST['senha_cad'];
    $senha_conf = $_POST['conf_senha'];


    $erro=" ";

    $validador = new ValidarCadastro($nome, $CPF, $CNPJ, $dta_nasc, $email, $email_conf, $senha, $senha_conf, $conn);
    $validar_itens->validacao();
    

    inserir_cadastro($nome,$CPF,$CNPJ,$dta_nascc,$email,$senha);
  

    echo"
    <!DOCTYPE html>
          <html lang='pt-BR'>
          <head>
              <meta charset='UTF-8'>
              <meta name='viewport' content='width=device-width, initial-scale=1.0'>
              <link rel='stylesheet' type='text/css' href='../CSS/css_cadastro_login.css'>
              <title>Cadastro realizado com sucesso!</title>
          </head>
          <body>

          <div class='main'>
              <div class='caixa_texto'>
                  <h1>Cadastro realizado com sucesso</h1><br>
                  <a href='../login.html'>Fazer login</a>
              </div>
           </div>
          </body>
          </html>";
    

    
                
                
                
        
                // Redireciona para uma página de sucesso
                exit();
            } 

           
         
        
    

    // Se houver erro, redireciona de volta para o formulário com a mensagem de erro
    if (!empty($erro)) {
      
        header("Location: ../cadastro.html?erro=" . urlencode($erro));
     
      
        exit();
    }


$conn->close();
?>