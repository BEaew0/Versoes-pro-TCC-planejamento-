<?php
declare(strict_types=1);

function inserir_cadastro(object $conn, string $nome, string $CPF, string $CNPJ, string $dta, string $email, string $senha) {
    // Preparar o hash da senha ANTES de inserir
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
    
    // Preparar a query
    $comando = $conn->prepare("INSERT INTO tb_cadastro 
                             (nome_cadastro, CPF_cadastro, CNPJ_cadastro, 
                              dta_nasc_cadastro, email_cadastro, senha_cadastro) 
                             VALUES (?, ?, ?, ?, ?, ?)");
    
    // Vincular parâmetros (agora incluindo o hash da senha)
    $comando->bind_param("ssssss", $nome, $CPF, $CNPJ, $dta, $email, $senha_hash);
    
    // Executar a query
    $result = $comando->execute();
    
    // Retornar o resultado da operação
    return $result;
}



function get_user_login(object $conn, string $tipo, string $senha) {
    // Remove caracteres não numéricos

    
    
    // Prepara a consulta SQL
    $comando = "SELECT id_cadastro, nome_cadastro, CPF_cadastro, senha_cadastro FROM tb_cadastro";

    
    // Executa a consulta
    if (strlen($tipo) == 11) 
    {
        // Se for CPF (11 caracteres)
        $comando .= " WHERE CPF_cadastro = ?";
    } else if (strlen($tipo) == 14)
     {
        // Se for CNPJ (14 caracteres)
        $comando .= " WHERE CNPJ_cadastro = ?";
    } 
    else 
    {
        echo "CPF ou CNPJ inválido!";
        exit;
    }

    $comando = $conn->prepare($comando);
    $comando->bind_param("s", $tipo);
    // Obtém o resultado
    $comando->execute();
    $resultado = $comando->get_result();
    
     if ($resultado->num_rows > 0) {
        // Usuário encontrado, verifica a senha
        $usuario = $resultado->fetch_assoc();

        if (password_verify($senha, $usuario['senha_cadastro'])) {
            // Senha correta, salva os dados na sessão
    
            $_SESSION['nome_usuario'] = $usuario['nome_cadastro'];
            $_SESSION['tipo_usuario'] = (strlen($tipo) == 11) ? 'CPF' : 'CNPJ';

            echo "<meta HTTP-EQUIV='refresh' CONTENT='5;URL=../pag_principal.html'>";
            exit();
        }
        else 
        {
            echo "Senha incorreta!";
            exit;
        }
    } 
    else
    {
        echo "Usuário não encontrado!";
        exit;
    }

              
    
   }

   ?>