<?php
declare(strict_types=1);

class itens_validar {
    public string $nome;
    public string $CPF;
    public string $CNPJ;
    public string $dta_nasc;
    public string $email;
    public string $conf_email;
    public string $senha;
    public string $conf_senha;
}

class ValidarCadastro {
    private itens_validar $dados;
    private object $conn;

    function __construct(
        string $nome, 
        string $CPF, 
        string $CNPJ,
        string $dta_nasc, 
        string $email, 
        string $conf_email, 
        string $senha, 
        string $conf_senha, 
        object $conn
    ) {
        $this->dados = new itens_validar();
        $this->dados->nome = $nome;
        $this->dados->CPF = $CPF;
        $this->dados->CNPJ = $CNPJ;
        $this->dados->dta_nasc = $dta_nasc;
        $this->dados->email = $email;
        $this->dados->conf_email = $conf_email;
        $this->dados->senha = $senha;
        $this->dados->conf_senha = $conf_senha;
        $this->conn = $conn;
    }

    function validacao(): array {
        $errors = [];
        
        $data = [
            'nome' => $this->dados->nome,
            'CPF' => $this->dados->CPF,
            'CNPJ' => $this->dados->CNPJ,
            'dta_nascimento' => $this->dados->dta_nasc,
            'email' => $this->dados->email,
            'conf_email' => $this->dados->conf_email,
            'senha' => $this->dados->senha,
            'conf_senha' => $this->dados->conf_senha
        ];

        foreach ($data as $campo => $valor) {
            switch ($campo) {
                case 'nome':
                    if (empty($valor)) 
                    {
                        $errors['nome'] = 'Nome é obrigatório';
                    } elseif (strlen($valor) < 3) 
                    {
                        $errors['nome'] = 'Nome deve ter pelo menos 3 caracteres';
                    }
                    break;
                    
                case 'CPF':
                    if (!empty($valor) && !$this->validarCPF($valor)) {
                        $errors['CPF'] = 'CPF inválido';
                    } elseif (empty($valor)) {
                        $errors['CPF'] = 'Preencha seu CPF';
                    }
                    break;
                    
                case 'CNPJ':
                    if (!empty($valor) && !$this->validarCNPJ($valor)) {
                        $errors['CNPJ'] = 'CNPJ inválido';
                    }
                    break;
                    
                case 'dta_nascimento':
                    if (empty($valor)) {
                        $errors['dta_nascimento'] = 'Insira sua data de nascimento';
                    }
                    break;
                    
                case 'email':
                    if (empty($valor)) {
                        $errors['email'] = 'Email é obrigatório';
                    } elseif (!filter_var($valor, FILTER_VALIDATE_EMAIL)) {
                        $errors['email'] = 'Email inválido';
                    }
                    break;
                    
                case 'conf_email':
                    if ($valor !== $this->dados->email) {
                        $errors['conf_email'] = 'Emails não coincidem';
                    }
                    break;
                    
                case 'senha':
                    if (empty($valor)) {
                        $errors['senha'] = 'Senha é obrigatória';
                    } elseif (strlen($valor) < 8) {
                        $errors['senha'] = 'Senha deve ter pelo menos 8 caracteres';
                    }
                    break;
                    
                case 'conf_senha':
                    if ($valor !== $this->dados->senha) {
                        $errors['conf_senha'] = 'Senhas não coincidem';
                    }
                    break;
            }
        }

        return $errors;
    }

    public function validarCPF(string $CPF): bool {
        $CPF = preg_replace('/[^0-9]/is', '', $CPF);
     
        if (strlen($CPF) != 11) {
            return false;
        }
    
        if (preg_match('/(\d)\1{10}/', $CPF)) {
            return false;
        }

        $D1 = 0;
        $D2 = 0;
    
        for ($i = 0, $x = 10; $i < 8; $i++, $x--) {
            $D1 += $CPF[$i] * $x;
        }
        
        for ($i = 0, $x = 11; $i < 9; $i++, $x--) {
            $D2 += $CPF[$i] * $x;
        }

        $V1 = $D1 % 11;
        $V2 = $D2 % 11;

        $resultado1 = ($V1 < 2) ? 0 : 11 - $V1;
        $resultado2 = ($V2 < 2) ? 0 : 11 - $V2;

        return $resultado1 == $CPF[9] && $resultado2 == $CPF[10];
    }

    public function validarCNPJ(string $CNPJ): bool {
        $CNPJ = preg_replace('/[^0-9]/', '', $CNPJ);
    
        if (strlen($CNPJ) != 14) {
            return false;
        }
    
        if (preg_match('/(\d)\1{13}/', $CNPJ)) {
            return false;
        }
    
        // Cálculo do primeiro dígito verificador
        for ($i = 0, $j = 5, $soma = 0; $i < 12; $i++) {
            $soma += $CNPJ[$i] * $j;
            $j = ($j == 2) ? 9 : $j - 1;
        }
    
        $resto = $soma % 11;
        $digito1 = ($resto < 2) ? 0 : 11 - $resto;
    
        if ($CNPJ[12] != $digito1) {
            return false;
        }
    
        // Cálculo do segundo dígito verificador
        for ($i = 0, $j = 6, $soma = 0; $i < 13; $i++) {
            $soma += $CNPJ[$i] * $j;
            $j = ($j == 2) ? 9 : $j - 1;
        }
    
        $resto = $soma % 11;
        $digito2 = ($resto < 2) ? 0 : 11 - $resto;
    
        return $CNPJ[13] == $digito2;
    }
}

class ValidarLogin {
    private itens_validar $dados;
    private object $conn;
    private string $tipo_usuario; // 'CPF' ou 'CNPJ'
    private ValidarCadastro $validador;

    function __construct(
        string $nome,
        string $senha,
        string $tipo,  //para checar se é CPF ou CNPJ
        object $conn
    ) {
        $this->dados = new itens_validar();
        $this->dados->nome = $nome;
        $this->dados->senha = $senha;
        $this->conn = $conn;
        
        // Cria instância do ValidarCadastro para usar suas funções
        $this->validador = new ValidarCadastro('', $tipo, '', '', '', '', '', '', $conn);
        
        // Remove caracteres não numéricos
        $identificador_limpo = preg_replace('/[^0-9]/', '', $tipo,);
        
        // Valida CPF ou CNPJ
        if (strlen($tipo) == 11 && $this->validador->validarCPF($tipo,)) 
        {
            $this->dados->CPF = $identificador_limpo;
            $this->tipo_usuario = 'CPF';
        } elseif (strlen($identificador_limpo) == 14 && $this->validador->validarCNPJ($identificador_limpo)) {
            $this->dados->CNPJ = $identificador_limpo;
            $this->tipo_usuario = 'CNPJ';
        }
    }

    

    // ... restante dos métodos permanece igual ...
}