<?php
function Mostrar_erros_log() {
    if (isset($_SESSION['login_errors'])) {
        echo '<script>
        document.addEventListener("DOMContentLoaded", function() {
            var divErro = document.querySelector("[name=\'mostrar_erro\']") || document.getElementById("mostrar_msg");
            if (divErro) {
                divErro.innerHTML = \''.json_encode($_SESSION['login_errors']).'\';
           
            }
        });
        </script>';
        unset($_SESSION['login_errors']);
    }
}
?>