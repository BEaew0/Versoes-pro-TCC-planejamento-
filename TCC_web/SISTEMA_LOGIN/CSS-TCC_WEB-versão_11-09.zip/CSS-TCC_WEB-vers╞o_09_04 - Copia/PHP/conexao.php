<?php
$servername = "localhost"; 
$username = "root"; 
$password = "";
$banconame = "banco_tesouro_azul_tw"; 

$conn = new mysqli($servername, $username, $password, $banconame);
//cria a conexão


if ($conn->connect_error) 
{

    die("Conexão falhou: " . $conn->connect_error);
} 
else
{
    
}
?>
