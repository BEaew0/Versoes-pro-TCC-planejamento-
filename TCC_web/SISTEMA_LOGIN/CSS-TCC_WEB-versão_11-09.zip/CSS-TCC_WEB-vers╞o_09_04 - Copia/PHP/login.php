<?php
// Inicia a sessão no início do arquivo
session_start();

// Configura o cabeçalho antes de qualquer saída
header('Content-Type: text/html; charset=utf-8');

// Inclui os arquivos necessários
require_once 'conexao.php';
require_once 'selects.php';
require_once 'validacao.php';
require_once 'mostrar_erros.php';

// Verifica se a requisição é POST e se os campos existem
if ($_SERVER['REQUEST_METHOD'] === 'POST' && 
    isset($_POST['botao'], $_POST['nome_login'], $_POST['log_pessoa'], $_POST['senha_log']) && 
    $_POST['botao'] === 'logar') {
    
    try {
        // Obtém e limpa os dados do formulário
        $nome = trim($_POST['nome_login']);
        $identificador = preg_replace('/[^0-9]/', '', $_POST['log_pessoa']);
        $senha = $_POST['senha_log'];

        // Cria o validador
        $validador = new ValidarLogin($nome, $identificador, $senha);
        $erros = $validador->validarDados();


        // Se houver erros de validação
        if (!empty($erros)) {
            $_SESSION['erro_login'] = implode("<br>", $erros);
            header("Location: ../login.html");
            exit();
        }

        // Autenticação
        $usuario = Login_usuario($conn, $nome, $identificador, $senha);

        if ($usuario) {
            // Configura a sessão
            $_SESSION['id_usuario'] = $usuario['id_cadastro'];
            $_SESSION['nome_usuario'] = $usuario['nome_cadastro'];
            $_SESSION['tipo_usuario'] = (strlen($identificador) == 11) ? 'CPF' : 'CNPJ';
            
            // Redireciona para a página principal
            header("Location: ../home.html");
            exit();
        } else {
            throw new Exception("Credenciais inválidas");
        }
    } catch (Exception $e) {
        $erro = json_encode($erros); // Envia os erros como JSON pela URL ou use SESSION se preferir
        json_decode($erro);

        
        header("Location: ../login.html");

        exit();
    }
} else {
    // Redireciona para login se não for uma requisição POST válida
    header("Location: ../login.html");
    exit();
}
?>