<?php
declare(strict_types=1);
require_once 'mostrar_erros.php';

class ItensValidar 
{
    public string $nome;
    public string $CPF;
    public string $CNPJ;
    public string $dta_nasc;
    public string $email;
    public string $conf_email;
    public string $senha;
    public string $conf_senha;
}

class ValidarCadastro 
{
    private ItensValidar $dados;
    private object $conn;

    public function __construct(
        string $nome, 
        string $CPF, 
        string $CNPJ,
        string $dta_nasc, 
        string $email, 
        string $conf_email, 
        string $senha,  
        string $conf_senha,  
        object $conn
    ) {
        $this->dados = new ItensValidar();
        $this->dados->nome = trim($nome);
        $this->dados->CPF = preg_replace('/[^0-9]/', '', $CPF);
        $this->dados->CNPJ = preg_replace('/[^0-9]/', '', $CNPJ);
        $this->dados->dta_nasc = $dta_nasc;
        $this->dados->email = trim($email);
        $this->dados->conf_email = trim($conf_email);
        $this->dados->senha = $senha;
        $this->dados->conf_senha = $conf_senha;
        $this->conn = $conn;
    }

    public function validacao(): array 
    {
        $errors = [];
        
        // Validação do nome
        if (empty($this->dados->nome)) {
            $errors['nome'] = 'Nome é obrigatório';
        } elseif (strlen($this->dados->nome) < 3) {
            $errors['nome'] = 'Nome deve ter pelo menos 3 caracteres';
        }

        // Validação do CPF/CNPJ (pelo menos um deve ser preenchido)
        if (empty($this->dados->CPF) && empty($this->dados->CNPJ)) {
            $errors['documento'] = 'CPF ou CNPJ é obrigatório';
        } else {
            if (!empty($this->dados->CPF) && !$this->validarCPF($this->dados->CPF)) {
                $errors['CPF'] = 'CPF inválido';
            }
            if (!empty($this->dados->CNPJ) && !$this->validarCNPJ($this->dados->CNPJ)) {
                $errors['CNPJ'] = 'CNPJ inválido';
            }
        }

        // Validação da data de nascimento
        if (empty($this->dados->dta_nasc)) {
            $errors['dta_nasc'] = 'Data de nascimento é obrigatória';
        } elseif (!DateTime::createFromFormat('Y-m-d', $this->dados->dta_nasc)) {
            $errors['dta_nasc'] = 'Formato de data inválido (use AAAA-MM-DD)';
        }

        // Validação do email
        if (empty($this->dados->email)) {
            $errors['email'] = 'Email é obrigatório';
        } elseif (!filter_var($this->dados->email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email inválido';
        } elseif ($this->dados->email !== $this->dados->conf_email) {
            $errors['conf_email'] = 'Emails não coincidem';
        }

        // Validação da senha
        if (empty($this->dados->senha)) {
            $errors['senha'] = 'Senha é obrigatória';
        } elseif (strlen($this->dados->senha) < 8) {
            $errors['senha'] = 'Senha deve ter pelo menos 8 caracteres';
        } elseif ($this->dados->senha !== $this->dados->conf_senha) {
            $errors['conf_senha'] = 'Senhas não coincidem';
        }


        if (!empty($errors)) {
            $_SESSION["login_errors"] = $errors;
            header("Location: ../login.php");
            die();
        }



    }

    public function validarCPF(string $CPF): bool 
    {
        // Implementação da validação de CPF (mantida como no seu código original)
        $CPF = preg_replace('/[^0-9]/', '', $CPF);
        
        if (strlen($CPF) != 11) {
            return false;
        }
        
        if (preg_match('/^(\d)\1{10}$/', $CPF)) {
            return false;
        }
        
        $soma = 0;
        for ($i = 0; $i < 9; $i++) {
            $soma += $CPF[$i] * (10 - $i);
        }
        $resto = $soma % 11;
        $dv1 = ($resto < 2) ? 0 : 11 - $resto;
        
        $soma = 0;
        for ($i = 0; $i < 10; $i++) {
            $soma += $CPF[$i] * (11 - $i);
        }
        $resto = $soma % 11;
        $dv2 = ($resto < 2) ? 0 : 11 - $resto;
        
        return ($CPF[9] == $dv1 && $CPF[10] == $dv2);
    }

    public function validarCNPJ(string $CNPJ): bool 
    {
        // Implementação da validação de CNPJ (mantida como no seu código original)
        $CNPJ = preg_replace('/[^0-9]/', '', $CNPJ);
        
        if (strlen($CNPJ) != 14) {
            return false;
        }
        
        if (preg_match('/^(\d)\1{13}$/', $CNPJ)) {
            return false;
        }
        
        $soma = 0;
        $pesos = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        for ($i = 0; $i < 12; $i++) {
            $soma += $CNPJ[$i] * $pesos[$i];
        }
        $digito1 = ($soma % 11 < 2) ? 0 : 11 - ($soma % 11);
        
        $soma = 0;
        $pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
        for ($i = 0; $i < 13; $i++) {
            $soma += $CNPJ[$i] * $pesos[$i];
        }
        $digito2 = ($soma % 11 < 2) ? 0 : 11 - ($soma % 11);
        
        return ($CNPJ[12] == $digito1 && $CNPJ[13] == $digito2);
    }
}

class ValidarLogin 
{
    private string $nome;
    private string $identificador;
    private string $senha;
    private object $conn;

    public function __construct(
        string $nome,
        string $identificador, 
        string $senha,
        object $conn
    ) 
    {
        $this->nome = trim($nome);
        $this->identificador = preg_replace('/[^0-9]/', '', $identificador);
        $this->senha = $senha;
        $this->conn = $conn;
    }



    public function validarDados(): array 
    {
        $errors = [];
        
        if (empty($this->nome)) {
            $errors['nome'] = 'Nome é obrigatório';
        }
        
        if (empty($this->identificador)) {
            $errors['identificador'] = 'CPF/CNPJ é obrigatório';
        } elseif (strlen($this->identificador) !== 11 && strlen($this->identificador) !== 14) {
            $errors['identificador'] = 'CPF deve ter 11 dígitos ou CNPJ 14 dígitos';
        }


        
        if (empty($this->senha)) {
            $errors['senha'] = 'Senha é obrigatória';
        } elseif (strlen($this->senha) < 8) {
            $errors['senha'] = 'Senha deve ter pelo menos 8 caracteres';
        }
        
        
        if (!empty($errors)) {
            $_SESSION["login_errors"] = $errors;
            header("Location: ../login.php");
            die();
        }
    }
}
?>