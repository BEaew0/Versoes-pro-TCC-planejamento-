<?php
session_start();
include 'conexao.php';
require 'selects.php';
include 'validacao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome_usuario'];
    $CPF = $_POST['CPF_usuario'];
    $CNPJ = $_POST['CNPJ_usuario'];
    $dta_nasc = $_POST['dta_nascimento'];
    $email = $_POST['email_usuario'];
    $email_conf = $_POST['conf_email'];
    $senha = $_POST['senha_cad'];
    $senha_conf = $_POST['conf_senha'];

    // Criar instância do validador
    $validador = new ValidarCadastro($nome, $CPF, $CNPJ, $dta_nasc, $email, $email_conf, $senha, $senha_conf, $conn);

    // Realizar validação e capturar os erros
    $erros = $validador->validacao();

    if (empty($erros)) 
    {
        // Se validação OK, inserir no banco
        if (inserir_cadastro($conn, $nome, $CPF, $CNPJ, $dta_nasc, $email, $senha)) {
            // Cadastro bem-sucedido
            echo "<!DOCTYPE html>
                  <html lang='pt-BR'>
                  <head>
                      <meta charset='UTF-8'>
                      <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                      <link rel='stylesheet' type='text/css' href='../CSS/css_cadastro_login.css'>
                      <title>Cadastro realizado com sucesso!</title>
                  </head>
                  <body>
                  <div class='main'>
                      <div class='caixa_texto'>
                          <h1>Cadastro realizado com sucesso</h1><br>
                          <a href='../login.html'>Fazer login</a>
                      </div>
                  </div>
                  </body>
                  </html>";
            exit();
        } else {
            $erro = "Erro ao inserir no banco de dados";
        }
    } 
    else 
    {
        // Caso existam erros de validação
        $erro = json_encode($erros); // Envia os erros como JSON pela URL ou use SESSION se preferir
        json_decode($erro);
    }

    // Se chegou aqui, houve algum erro
    header("Location: ../cadastro.html?erro=" . urlencode($erro));
    exit();
}

$conn->close();
?>
