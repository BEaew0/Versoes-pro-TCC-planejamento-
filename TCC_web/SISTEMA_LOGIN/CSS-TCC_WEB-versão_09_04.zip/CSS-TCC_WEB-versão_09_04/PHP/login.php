<?php
session_start();
header('Content-Type: text/html; charset=utf-8');

include 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['botao']) && $_POST['botao'] == 'logar') {
    // Verifica se todos os campos necessários estão presentes
    if (empty($_POST['nome_login']) || empty($_POST['log_pessoa']) || empty($_POST['senha_log'])) {
        $_SESSION['erro_login'] = "Todos os campos são obrigatórios";
        header("Location: ../login.html");
        exit();
    }

    // Coleta os dados do formulário
    $nome = trim($_POST['nome_login']);
    $identificador = preg_replace('/[^0-9]/', '', $_POST['log_pessoa']);
    $senha = $_POST['senha_log'];

    require_once "validacao.php";
    require_once "selects.php";

    try {
        // Validação do login
        $validar_login = new ValidarLogin($nome, $identificador, $senha, $conn);
        $erros = $validar_login->validarDados();

        if (!empty($erros)) {
            $_SESSION['erro_login'] = implode("<br>", $erros);
            header("Location: ../login.html");
            exit();
        }

        // Tentativa de login
        $usuario = Login_usuario($conn, $nome, $identificador, $senha);
        
        if ($usuario) {
            $_SESSION['usuario'] = $usuario;
            header("Location: .../pag_principal.html");
            exit();
        } else {
            $_SESSION['erro_login'] = "Credenciais inválidas ou usuário não encontrado";
            header("Location: ../login.html");
            exit();
        }
        
    } catch (InvalidArgumentException $e) {
        $_SESSION['erro_login'] = $e->getMessage();
        header("Location: ../login.html");
        exit();
    }
} else {
    // Acesso direto sem POST ou botão não definido
    header("Location: ../login.html");
    exit();
}
?>