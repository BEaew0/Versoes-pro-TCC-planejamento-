<?php
declare(strict_types=1);

class itens_validar 
{
    public string $nome;
    public string $CPF;
    public string $CNPJ;
    public string $dta_nasc;
    public string $email;
    public string $conf_email;
    public string $senha;
    public string $conf_senha;
}

class ValidarCadastro 
{
    private itens_validar $dados;
    private object $conn;

    function __construct( string $nome, string $CPF, string $CNPJ,string $dta_nasc, string $email, string $conf_email, string $senha,  string $conf_senha,  object $conn ) 
    {
        $this->dados = new itens_validar();
        $this->dados->nome = $nome;
        $this->dados->CPF = $CPF;
        $this->dados->CNPJ = $CNPJ;
        $this->dados->dta_nasc = $dta_nasc;
        $this->dados->email = $email;
        $this->dados->conf_email = $conf_email;
        $this->dados->senha = $senha;
        $this->dados->conf_senha = $conf_senha;
        $this->conn = $conn;
    }

    function validacao(): array 
    {
        $error = [];
        
        $data = 
        [
            'nome' => $this->dados->nome,
            'CPF' => $this->dados->CPF,
            'CNPJ' => $this->dados->CNPJ,
            'dta_nascimento' => $this->dados->dta_nasc,
            'email' => $this->dados->email,
            'conf_email' => $this->dados->conf_email,
            'senha' => $this->dados->senha,
            'conf_senha' => $this->dados->conf_senha
        ];

        foreach ($data as $campo => $valor) 
        {
            switch ($campo) 
            {
                case 'nome':
                    if (empty($valor)) 
                    {
                        $error['nome'] = 'Nome é obrigatório';
                    } 
                    elseif (strlen($valor) < 3) 
                    {
                        $error['nome'] = 'Nome deve ter pelo menos 3 caracteres';
                    }
                    break;
                    
                case 'CPF':
                    if (!empty($valor) && !$this->validarCPF($valor)) 
                    {
                        $error['CPF'] = 'CPF inválido';
                    }
                    elseif (empty($valor)) 
                    {
                        $error['CPF'] = 'Preencha seu CPF';
                    }
                    break;
                    
                case 'CNPJ':
                    if (!empty($valor) && !$this->validarCNPJ($valor)) 
                    {
                        $error['CNPJ'] = 'CNPJ inválido';
                    }
                    break;
                    
                case 'dta_nascimento':
                    if (empty($valor)) 
                    {
                        $error['dta_nascimento'] = 'Insira sua data de nascimento';
                    }
                    break;
                    
                case 'email':
                    if (empty($valor)) {
                        $errors['email'] = 'Email é obrigatório';
                    } 
                    elseif (!filter_var($valor, FILTER_VALIDATE_EMAIL)) 
                    {
                        $error['email'] = 'Email inválido';
                    }
                    break;
                    
                case 'conf_email':
                    if ($valor !== $this->dados->email) 
                    {
                        $error['conf_email'] = 'Emails não coincidem';
                    }
                    break;
                    
                case 'senha':
                    if (empty($valor)) 
                    {
                        $error['senha'] = 'Senha é obrigatória';
                    }
                    elseif (strlen($valor) < 8) 
                    {
                        $error['senha'] = 'Senha deve ter pelo menos 8 caracteres';
                    }
                    break;
                    
                case 'conf_senha':
                    if ($valor !== $this->dados->senha) 
                    {
                        $error['conf_senha'] = 'Senhas não coincidem';
                    }
                    break;
            }

            if(empty($data))
            {
                $error['data'] = 'Formulário em branco,preencha todos os campos indicados';
            }
        }

        return $error;
    }



    public function validarCPF(string $CPF): bool 
{
    // Remove todos os caracteres não numéricos
    $CPF = preg_replace('/[^0-9]/', '', $CPF);
    
    // Verifica se possui 11 dígitos
    if (strlen($CPF) != 11) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais (casos como 111.111.111-11)
    if (preg_match('/^(\d)\1{10}$/', $CPF)) {
        return false;
    }
    
    // Validação dos dígitos verificadores
    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($c = 0; $c < $t; $c++) {
            $soma += $CPF[$c] * (($t + 1) - $c);
        }
        $digito = (($soma % 11) < 2) ? 0 : 11 - ($soma % 11);
        
        if ($CPF[$c] != $digito) {
            return false;
        }
    }
    
    return true;
}


public function validarCNPJ(string $CNPJ): bool 
{
    // Remove todos os caracteres não numéricos
    $CNPJ = preg_replace('/[^0-9]/', '', $CNPJ);
    
    // Verifica se possui 14 dígitos
    if (strlen($CNPJ) != 14) {
        return false;
    }
    
    // Verifica se todos os dígitos são iguais (casos como 11.111.111/1111-11)
    if (preg_match('/^(\d)\1{13}$/', $CNPJ)) {
        return false;
    }
    
    // Validação do primeiro dígito verificador
    $soma = 0;
    $pesos = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    for ($i = 0; $i < 12; $i++) {
        $soma += $CNPJ[$i] * $pesos[$i];
    }
    $digito1 = ($soma % 11 < 2) ? 0 : 11 - ($soma % 11);
    
    // Validação do segundo dígito verificador
    $soma = 0;
    $pesos = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
    for ($i = 0; $i < 13; $i++) {
        $soma += $CNPJ[$i] * $pesos[$i];
    }
    $digito2 = ($soma % 11 < 2) ? 0 : 11 - ($soma % 11);
    
    // Verifica se os dígitos calculados conferem com os informados
    return ($CNPJ[12] == $digito1) && ($CNPJ[13] == $digito2);
}
}


class ValidarLogin {
    private itens_validar $dados;
    private object $conn;
    private string $tipo_usuario; // 'CPF' ou 'CNPJ'
    private ValidarCadastro $validador;

    function __construct(string $nome,string $senha,string $tipo_identificacao, object $conn) 
    {
        $this->dados = new itens_validar();
        $this->dados->nome = $nome;
        $this->dados->senha = $senha;
        $this->conn = $conn;
        $this->tipo_usuario = '';
        
        $this->validador = new ValidarCadastro('', $tipo_identificacao, '', '', '', '', '', '', $conn);
        
        $this->validarIdentificador($tipo_identificacao);
    }

    private function validarIdentificador(string $tipo_identificacao): void 
    {
        $identificador_limpo = preg_replace('/[^0-9]/', '', $tipo_identificacao);
        
        if (strlen($identificador_limpo) == 11 && $this->validador->validarCPF($identificador_limpo)) 
        {
            $this->dados->CPF = $identificador_limpo;
            $this->tipo_usuario = 'CPF';
        } 
        elseif (strlen($identificador_limpo) == 14 && $this->validador->validarCNPJ($identificador_limpo)) 
        {
            $this->dados->CNPJ = $identificador_limpo;
            $this->tipo_usuario = 'CNPJ';
        } 
        else 
        {
            throw new InvalidArgumentException('Identificador inválido. Deve ser CPF ou CNPJ válido.');
        }
    }

    public function validarDados(): array 
    {
        $errors = [];
        
        if (empty($this->dados->nome)) 
        {
            $errors['nome'] = 'Nome é obrigatório';
        }
        
        if (empty($this->dados->senha)) 
        {
            $errors['senha'] = 'Senha é obrigatória';
        }
        
        if (empty($this->tipo_usuario)) 
        {
            $errors['identificador'] = 'CPF/CNPJ inválido';
        }
        
        return $errors;
    }

    
}

    // ... restante dos métodos permanece igual ...
